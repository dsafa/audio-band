Enums
=================

.. literalinclude:: ../../musicbeeipc/enums.py