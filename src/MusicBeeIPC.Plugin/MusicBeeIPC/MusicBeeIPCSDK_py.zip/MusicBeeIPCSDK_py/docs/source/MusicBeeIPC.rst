MusicBeeIPC class
=================

.. autoclass:: musicbeeipc.musicbeeipc.MusicBeeIPC
    :members:
