Readme
======

**Author:** Kerli Low

**Email:** kerlilow@gmail.com

**Homepage:** http://www.zorexxlkl.com/musicbeeipc

**Description:** Control MusicBee with Python using the MusicBeeIPC plugin.

| **Installation:**  
|     Run the setup.py file
    
| **License:**  
|     BSD 2-Clause License (See LICENSE_MusicBeeIPCSDK.txt)
