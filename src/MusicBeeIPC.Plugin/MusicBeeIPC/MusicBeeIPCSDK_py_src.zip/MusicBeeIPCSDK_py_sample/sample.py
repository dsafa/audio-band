﻿import os
import struct
from win32ui import MessageBox
from musicbeeipc import *

mbIPC = MusicBeeIPC()

print("MusicBee Version: " + mbIPC.get_music_bee_version_str())
print("MusicBeeIPC Version: " + mbIPC.get_plugin_version_str())

MessageBox(mbIPC.get_file_tag(MBMD_Artist), "Artist", 0)

MessageBox(mbIPC.get_file_tag(MBMD_TrackTitle), "Track Title", 0)

print("State: " + mbIPC.get_play_state_str())
print("Current Index: " + str(mbIPC.get_current_index()))

mbIPC.jump(int(input("Jump to: ")))

result = mbIPC.search("You")
msg = 'Songs containing the keyword "You":\n'
for r in result:
    msg += r + "\n"
    
MessageBox(msg, "Search Result", 0)

result = mbIPC.search("2012", "Is", ["Year"])
msg = "Songs released in the year 2012:\n"
for r in result:
    msg += r + "\n"
    
MessageBox(msg, "Search Result", 0)

print("Number of items in the now playing list: " + str(mbIPC.now_playing_list_get_item_count()))

os.system("pause")
