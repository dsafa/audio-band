﻿MusicBeeIPC SDK for Python
==========================

Author: Kerli Low

Email: kerlilow@gmail.com

Homepage: http://www.zorexxlkl.com/musicbeeipc

Description: Control MusicBee with Python using the MusicBeeIPC plugin.

Installation:
    setup.py install
    
License:
    BSD 2-Clause License (See LICENSE_MusicBeeIPCSDK.txt)
