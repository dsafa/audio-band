.. musicbeeipc documentation master file, created by
   sphinx-quickstart on Tue Mar 25 00:20:26 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

MusicBeeIPC SDK for Python
==========================

.. toctree::

   Readme
   MusicBeeIPC
   Enums
   License
   