License
=======

.. literalinclude:: ../../LICENSE_MusicBeeIPCSDK.txt