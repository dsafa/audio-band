﻿MusicBeeIPC
===========

Author: Kerli Low

Email: kerlilow@gmail.com

Homepage: http://www.zorexxlkl.com/musicbeeipc

Description:
    Control MusicBee without using the plugin interface, with various
    programming/scripting languages.
    SDKs are provided for C++, C#, Java, Python, Ruby, AutoHotkey, and AutoIt.
    Please visit the homepage (http://www.zorexxlkl.com/musicbeeipc) for more
    information.

Installation:
    Copy the MusicBeeIPC.dll into your MusicBee Plugins folder.
    (Usually located at C:\Program Files (x86)\MusicBee\Plugins)
    
License:
    GNU GPLv3 (See COPYING for more information.)
