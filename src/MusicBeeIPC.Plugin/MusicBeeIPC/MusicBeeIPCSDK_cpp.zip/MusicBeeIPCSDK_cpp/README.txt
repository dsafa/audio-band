﻿MusicBeeIPC SDK for C++
=======================

Author: Kerli Low

Email: kerlilow@gmail.com

Homepage: http://www.zorexxlkl.com/musicbeeipc

Description: Control MusicBee with C++ using the MusicBeeIPC plugin.

Installation:
    Include the src files and add the include directory to your project.
    
License:
    BSD 2-Clause License (See LICENSE_MusicBeeIPCSDK.txt)
